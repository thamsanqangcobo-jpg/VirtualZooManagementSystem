﻿using System;
using System.Collections.Generic;

public class Animal
{
    public string Name { get; set; }
    public int Age { get; set; }

    public virtual void Eat()
    {
        Console.WriteLine("Animal is eating.");
    }

    public virtual void Sleep()
    {
        Console.WriteLine("Animal is sleeping.");
    }
}

public interface IFeedable
{
    void Feed();
}

public interface IMovable
{
    void Move();
}

public class Lion : Animal, IFeedable, IMovable
{
    public override void Eat()
    {
        Console.WriteLine("Lion is eating meat.");
    }

    public override void Sleep()
    {
        Console.WriteLine("Lion is sleeping in the shade.");
    }

    public void Feed()
    {
        Eat();
    }

    public void Move()
    {
        Console.WriteLine("Lion is walking around.");
    }
}

public class Parrot : Animal, IFeedable, IMovable
{
    public override void Eat()
    {
        Console.WriteLine("Parrot is eating seeds.");
    }

    public override void Sleep()
    {
        Console.WriteLine("Parrot is sleeping on its perch.");
    }

    public void Feed()
    {
        Eat();
    }

    public void Move()
    {
        Console.WriteLine("Parrot is flying around.");
    }
}



public class Turtle : Animal, IFeedable, IMovable
{
    public override void Eat()
    {
        Console.WriteLine("Turtle is eating lettuce.");
    }

    public override void Sleep()
    {
        Console.WriteLine("Turtle is sleeping underwater.");
    }

    public void Feed()
    {
        Eat();
    }

    public void Move()
    {
        Console.WriteLine("Turtle is swimming.");
    }
}

class Program
{
    static void Main()
    {
        List<Animal> animals = new List<Animal>
{
            new Lion { Name = "Alex", Age = 5 },
            new Parrot { Name = "Polly", Age = 2 },
            new Turtle { Name = "Solomon", Age = 23 }
};

        bool addingAnimals = true;
        while (addingAnimals)
        {
            Console.WriteLine("Select an animal to add:");
            Console.WriteLine("1. Lion");
            Console.WriteLine("2. Parrot");
            Console.WriteLine("3. Turtle");
            Console.WriteLine("0. Done adding animals");

            int choice = Convert.ToInt32(Console.ReadLine());
            switch (choice)
            {
                case 1:
                    Console.Write("Enter Lion's name: ");
                    string lionName = Console.ReadLine();
                    Console.Write("Enter Lion's age: ");
                    int lionAge = Convert.ToInt32(Console.ReadLine());
                    animals.Add(new Lion { Name = lionName, Age = lionAge });
                    break;
                case 2:
                    Console.Write("Enter Parrot's name: ");
                    string parrotName = Console.ReadLine();
                    Console.Write("Enter Parrot's age: ");
                    int parrotAge = Convert.ToInt32(Console.ReadLine());
                    animals.Add(new Parrot { Name = parrotName, Age = parrotAge });
                    break;
                case 3:
                    Console.Write("Enter Turtle's name: ");
                    string turtleName = Console.ReadLine();
                    Console.Write("Enter Turtle's age: ");
                    int turtleAge = Convert.ToInt32(Console.ReadLine());
                    animals.Add(new Turtle { Name = turtleName, Age = turtleAge });
                    break;
                case 0:
                    addingAnimals = false;
                    break;
                default:
                    Console.WriteLine("Invalid choice.");
                    break;
            }
        }

        foreach (var animal in animals)
        {
            Console.WriteLine($"{animal.Name} ({animal.GetType().Name}):");
            animal.Eat();
            animal.Sleep();

            if (animal is IFeedable feedableAnimal)
            {
                Console.Write($"{animal.Name} can be fed. ");
                feedableAnimal.Feed();
            }

            if (animal is IMovable movableAnimal)
            {
                Console.Write($"{animal.Name} can move. ");
                movableAnimal.Move();
            }

            Console.WriteLine();
        }
    }
}